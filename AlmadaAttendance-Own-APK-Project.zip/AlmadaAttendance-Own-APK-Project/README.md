# Almada Attendance — own Android APK source project

This is a source project that can build an Android debug APK using GitHub Actions. It is **not itself a compiled APK**. It uses Supabase as a backend database/auth/storage service; it does not depend on a third-party attendance app.

## Included
- Mobile-friendly app packaged with Capacitor for Android
- Email/password sign-up and login
- Employee, supervisor and admin roles
- Selfie upload to a private storage bucket
- GPS coordinates recorded at check-in/check-out
- Registered sites
- Check-in / check-out
- Date-filtered reports and CSV export for Excel
- SQL schema and row-level security policies
- GitHub Actions workflow to compile the APK

## Step A — Create your database
1. Go to https://supabase.com/ and create a project (choose a strong database password).
2. Open **SQL Editor** in the project.
3. Copy and run `supabase/setup.sql`.
4. Open **Storage** and create a bucket named exactly `attendance-selfies`. Keep it **Private**.
5. In **Project Settings → API**, copy the Project URL and the publishable/anon key. Never use the `service_role` secret key in the app.

## Step B — Build the APK
1. Sign in to https://github.com/ and create a new repository named `AlmadaAttendance`.
2. Upload all files from this folder, including the hidden `.github/workflows/build-apk.yml` file and the `supabase` folder.
3. Open **Actions** → **Build Almada Attendance APK** → **Run workflow**. If the workflow is disabled, enable Actions for the repository.
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run and download the artifact **AlmadaAttendance-APK**.
6. Extract the artifact; it contains `app-debug.apk`. Transfer it to your Android phone and tap it to install. You may need to allow installation from that source.

## Step C — Connect app to database
1. Open Almada Attendance on your phone.
2. Enter the Supabase Project URL and publishable/anon key.
3. Create the first account with your admin email and password.
4. If email confirmation is enabled, confirm the email and sign in.
5. In Supabase SQL Editor, promote that first account to admin by running:
   `update public.profiles set role = 'admin' where email = 'YOUR-ADMIN-EMAIL';`
   Replace the email with your actual admin email.
6. Sign out and back in so the app reloads the role.
7. Admin adds registered work sites. Employees can create their accounts; the admin can promote approved supervisors in the Employees tab.

## Important production limitations
- This is an initial MVP. Test camera/GPS on real devices before use.
- GPS coordinates are captured, but the current MVP does not yet enforce the configured site radius server-side or prevent GPS spoofing.
- The app stores attendance rows in the shared Supabase database. Employee reads are restricted to their own rows; admin/supervisor reads are permitted by RLS.
- Attendance photo paths are private, but this MVP does not yet display signed photo previews in the reports.
- Supabase public client keys are intended for client use; database security depends on the provided RLS policies. Never embed a service-role key.
- For real company use, review Bahrain personal-data obligations, employee notice/consent as appropriate, data retention, backups, password reset and account recovery, and production release signing.
- The generated APK is a debug build. For a signed release or Play Store distribution, create and protect a signing key and follow Android release signing procedures.
- Keep GitHub repository private if you do not want source code public; GitHub Actions availability depends on account/repository plan.
