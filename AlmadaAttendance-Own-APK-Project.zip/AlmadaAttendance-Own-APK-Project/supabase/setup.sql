-- Almada Attendance database setup for Supabase
-- Run this whole file in Supabase Dashboard -> SQL Editor.
-- Create a PRIVATE Storage bucket named attendance-selfies separately (Storage -> New bucket).

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  role text not null default 'employee' check (role in ('admin','supervisor','employee')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, email, full_name, role)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)), 'employee')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.current_app_role()
returns text
language sql stable security definer set search_path = ''
as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.is_attendance_manager()
returns boolean
language sql stable security definer set search_path = ''
as $$
  select coalesce(public.current_app_role() in ('admin','supervisor'), false)
$$;

create table if not exists public.sites (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  address text not null,
  radius_m integer not null default 200 check (radius_m between 50 and 5000),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  employee_name text,
  site_id uuid references public.sites(id) on delete set null,
  site_name text not null,
  work_day date not null,
  check_in timestamptz not null default now(),
  check_out timestamptz,
  check_in_lat double precision not null,
  check_in_lon double precision not null,
  check_in_accuracy integer,
  check_out_lat double precision,
  check_out_lon double precision,
  check_out_accuracy integer,
  selfie_path text,
  check_out_selfie_path text,
  note text,
  checkout_note text,
  created_at timestamptz not null default now()
);

create index if not exists attendance_user_day_idx on public.attendance(user_id, work_day desc);
create index if not exists attendance_day_idx on public.attendance(work_day desc);

alter table public.profiles enable row level security;
alter table public.sites enable row level security;
alter table public.attendance enable row level security;

drop policy if exists "Profiles visible to signed-in users" on public.profiles;
create policy "Profiles visible to signed-in users" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_attendance_manager());

drop policy if exists "Admin can update profiles" on public.profiles;
create policy "Admin can update profiles" on public.profiles for update to authenticated
using (public.current_app_role() = 'admin')
with check (public.current_app_role() = 'admin');

drop policy if exists "Users can read sites" on public.sites;
create policy "Users can read sites" on public.sites for select to authenticated using (true);

drop policy if exists "Managers can insert sites" on public.sites;
create policy "Managers can insert sites" on public.sites for insert to authenticated
with check (public.is_attendance_manager() and created_by = auth.uid());

drop policy if exists "Managers can update sites" on public.sites;
create policy "Managers can update sites" on public.sites for update to authenticated
using (public.is_attendance_manager()) with check (public.is_attendance_manager());

drop policy if exists "Admins can delete sites" on public.sites;
create policy "Admins can delete sites" on public.sites for delete to authenticated
using (public.current_app_role() = 'admin');

drop policy if exists "Employees see own attendance managers see all" on public.attendance;
create policy "Employees see own attendance managers see all" on public.attendance for select to authenticated
using (user_id = auth.uid() or public.is_attendance_manager());

drop policy if exists "Users can create own attendance" on public.attendance;
create policy "Users can create own attendance" on public.attendance for insert to authenticated
with check (user_id = auth.uid());

drop policy if exists "Users can update own attendance" on public.attendance;
create policy "Users can update own attendance" on public.attendance for update to authenticated
using (user_id = auth.uid() or public.current_app_role() = 'admin')
with check (user_id = auth.uid() or public.current_app_role() = 'admin');

-- Create a PRIVATE Storage bucket named attendance-selfies in the dashboard.
-- These policies restrict photo access to the owner and attendance managers.
drop policy if exists "Owner uploads own attendance selfie" on storage.objects;
create policy "Owner uploads own attendance selfie" on storage.objects for insert to authenticated
with check (bucket_id = 'attendance-selfies' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "Owner and managers read attendance selfies" on storage.objects;
create policy "Owner and managers read attendance selfies" on storage.objects for select to authenticated
using (bucket_id = 'attendance-selfies' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_attendance_manager()));

drop policy if exists "Owner deletes own attendance selfie" on storage.objects;
create policy "Owner deletes own attendance selfie" on storage.objects for delete to authenticated
using (bucket_id = 'attendance-selfies' and ((storage.foldername(name))[1] = auth.uid()::text or public.current_app_role() = 'admin'));

-- After the first account has signed up, promote that account to admin in SQL Editor:
-- update public.profiles set role = 'admin' where email = 'YOUR-ADMIN-EMAIL';
