
import { createClient } from '@supabase/supabase-js';
import './style.css';

const CONFIG_KEY='almada_supabase_config_v1';
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let supabase=null, session=null, profile=null, sites=[], staff=[], attendance=[], gps=null, currentPhoto=null;
let activeTab='clock';

function bahrainDay(d=new Date()){
  return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Bahrain',year:'numeric',month:'2-digit',day:'2-digit'}).format(d);
}
function bahrainTimestamp(d=new Date()){
  return new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Bahrain',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(d).replace(' ','T')+'+03:00';
}
function isManager(){return ['admin','supervisor'].includes(profile?.role)}
function isAdmin(){return profile?.role==='admin'}
function message(id,text){const el=$(id);if(el)el.textContent=text}
function config(){try{return JSON.parse(localStorage.getItem(CONFIG_KEY)||'null')}catch{return null}}
function saveConfig(){const url=$('projectUrl').value.trim().replace(/\/$/,'');const key=$('anonKey').value.trim();if(!url.startsWith('https://')||!key){message('setupMsg','Enter your Supabase Project URL and publishable/anon key.');return}localStorage.setItem(CONFIG_KEY,JSON.stringify({url,key}));location.reload()}
function showSetup(){
 $('app').innerHTML=`<header><div class="brand"><div class="logo">A</div><div><h1>Almada Attendance</h1><p>Company attendance · Bahrain</p></div></div></header>
 <main class="wrap"><div class="notice"><b>First-time setup:</b> connect your own Supabase database. This is a backend service, not a third-party attendance app. Your company controls the project and records.</div>
 <div class="card" style="max-width:650px;margin:auto"><h2>Connect Almada's database</h2><p class="muted">Create a free Supabase project, run the SQL file included with this project, create the private storage bucket, then enter the project URL and public anon/publishable key here.</p>
 <div class="field"><label for="projectUrl">Supabase Project URL</label><input id="projectUrl" placeholder="https://your-project.supabase.co"></div>
 <div class="field"><label for="anonKey">Publishable / anon key</label><input id="anonKey" placeholder="sb_publishable_... or legacy anon key"></div>
 <button class="primary" id="saveConfig">Connect database</button><div id="setupMsg" class="msg"></div>
 <p class="muted">Never enter a service-role secret key in the app. The public key is protected by database Row Level Security policies.</p></div></main>`;
 $('saveConfig').onclick=saveConfig;
}
function renderAuth(){
 $('app').innerHTML=`<header><div class="brand"><div class="logo">A</div><div><h1>Almada Attendance</h1><p>Employee time and site attendance</p></div></div></header>
 <main class="wrap"><div class="notice">Use your company account. New users are created with the Employee role. An administrator must promote approved supervisors/admins.</div>
 <div class="card" style="max-width:520px;margin:auto"><h2>Sign in</h2><div class="field"><label>Email</label><input id="email" type="email" autocomplete="username" placeholder="name@company.com"></div><div class="field"><label>Password</label><input id="password" type="password" autocomplete="current-password" placeholder="At least 8 characters"></div><div class="actions"><button class="primary" id="loginBtn">Sign in</button><button id="signupBtn">Create employee account</button></div><div id="authMsg" class="msg"></div></div></main>`;
 $('loginBtn').onclick=async()=>{message('authMsg','Signing in…');const {error}=await supabase.auth.signInWithPassword({email:$('email').value.trim(),password:$('password').value});message('authMsg',error?.message||'Signed in. Loading…')};
 $('signupBtn').onclick=async()=>{message('authMsg','Creating account…');const {error}=await supabase.auth.signUp({email:$('email').value.trim(),password:$('password').value,options:{data:{full_name:$('email').value.trim()}}});message('authMsg',error?.message||'Account created. Check email if confirmation is enabled, then sign in.')};
}
function renderShell(){
 $('app').innerHTML=`<header><div class="brand"><div class="logo">A</div><div><h1>Almada Attendance</h1><p>Company attendance · Bahrain</p></div></div><div class="row" style="max-width:340px"><div><b id="who"></b><div class="muted" id="roleText" style="color:#d7e7f6"></div></div><button id="signOut">Sign out</button></div></header>
 <main class="wrap"><div class="tabs"><button class="tab active" data-tab="clock">Attendance</button><button class="tab" data-tab="reports">Reports</button><button class="tab manager-only" data-tab="sites">Work sites</button><button class="tab manager-only" data-tab="staff">Employees</button></div>
 <section id="panel-clock"><div class="grid">
 <div class="card third"><div class="metric" id="todayMetric">0</div><div class="metric-label">Today's records visible to you</div></div><div class="card third"><div class="metric" id="openMetric">0</div><div class="metric-label">Currently on duty</div></div><div class="card third"><div class="metric" id="siteMetric">0</div><div class="metric-label">Registered sites</div></div>
 <div class="card half"><h2>Check in / Check out</h2><div class="field"><label>Work site</label><select id="clockSite"></select></div><div class="field"><label>Selfie photo</label><input id="photo" type="file" accept="image/*" capture="user"><p class="muted">On most phones, this opens the camera. Photo uploads are private.</p></div><div class="field"><label>Note (optional)</label><input id="note" maxlength="180" placeholder="Site visit or work details"></div><div class="row"><div><label>GPS location</label><div class="muted" id="gpsText">Not captured</div></div><button id="gpsButton" class="fit">Get GPS</button></div><div class="actions"><button id="inButton" class="primary">Check In</button><button id="outButton">Check Out</button></div><div id="clockMsg" class="msg"></div></div>
 <div class="card half"><h2>My current shift</h2><div id="myShift" class="empty">No active shift.</div><h3 style="margin-top:18px">Latest activity</h3><div id="recent" class="muted">Loading…</div></div>
 <div class="card"><h2>Recent attendance</h2><div id="recentTable" class="table-wrap"></div></div></div></section>
 <section id="panel-reports" class="hidden"><div class="card"><h2>Attendance reports</h2><div class="grid"><div class="half field"><label>From</label><input id="fromDate" type="date"></div><div class="half field"><label>To</label><input id="toDate" type="date"></div><div class="half field"><label>Employee</label><select id="reportStaff"></select></div><div class="half field"><label>Work site</label><select id="reportSite"></select></div></div><div class="actions"><button id="filterBtn" class="primary">Apply filters</button><button id="csvBtn">Export CSV for Excel</button></div><p id="reportSummary" class="muted"></p><div id="reportTable" class="table-wrap"></div></div></section>
 <section id="panel-sites" class="hidden"><div class="grid"><div class="card half"><h2>Add work site</h2><div class="field"><label>Site name</label><input id="siteName" placeholder="e.g. Moda Mall"></div><div class="field"><label>Address / area</label><input id="siteAddress" placeholder="Manama, Bahrain"></div><div class="field"><label>Geofence radius in metres</label><input id="siteRadius" type="number" value="200" min="50" max="5000"></div><button id="addSite" class="primary">Add site</button><div id="siteMsg" class="msg"></div></div><div class="card half"><h2>Registered work sites</h2><div id="sitesTable" class="table-wrap"></div></div></div></section>
 <section id="panel-staff" class="hidden"><div class="card"><h2>Employee accounts and roles</h2><p class="muted">Employees create their own accounts. Select a role below to promote an account. Keep Admin access limited to trusted people.</p><div id="staffTable" class="table-wrap"></div><div id="staffMsg" class="msg"></div></div></section>
 <p class="footer">Almada Attendance · Bahrain time (UTC+3). Keep employee photo and location use transparent and limited to attendance purposes.</p></main>`;
 $('who').textContent=session.user.email;$('roleText').textContent='Role: '+(profile?.role||'employee');
 if(!isManager())document.querySelectorAll('.manager-only').forEach(el=>el.classList.add('hidden'));
 $('signOut').onclick=async()=>{await supabase.auth.signOut();location.reload()};
 document.querySelectorAll('[data-tab]').forEach(btn=>btn.onclick=()=>switchTab(btn.dataset.tab));
 $('gpsButton').onclick=captureGPS;
 $('photo').onchange=async e=>{const f=e.target.files?.[0];if(!f){currentPhoto=null;return}if(f.size>5*1024*1024){message('clockMsg','Please choose a selfie smaller than 5 MB.');e.target.value='';return}currentPhoto=f;message('clockMsg','Selfie selected. Capture GPS before submitting.')};
 $('inButton').onclick=()=>punch('in');$('outButton').onclick=()=>punch('out');
 $('addSite').onclick=addSite;$('filterBtn').onclick=renderReports;$('csvBtn').onclick=exportCSV;
 $('fromDate').value=bahrainDay().slice(0,7)+'-01';$('toDate').value=bahrainDay();
 loadData();
}
function switchTab(tab){activeTab=tab;document.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));['clock','reports','sites','staff'].forEach(p=>$('panel-'+p).classList.toggle('hidden',p!==tab));if(tab==='reports')renderReports();if(tab==='sites')renderSites();if(tab==='staff')renderStaff()}
async function loadData(){
 try{
  const [{data:s,error:se},{data:p,error:pe},{data:a,error:ae}]=await Promise.all([
   supabase.from('sites').select('*').order('name'),
   supabase.from('profiles').select('id,email,full_name,role').order('email'),
   supabase.from('attendance').select('*').order('check_in',{ascending:false}).limit(1000)
  ]);
  if(se)throw se;if(pe)throw pe;if(ae)throw ae;
  sites=s||[];staff=p||[];attendance=a||[];
  fillSelects();renderClock();renderSites();renderStaff();renderReports();
 }catch(e){message('clockMsg','Could not load data: '+e.message)}
}
function fill(el,items,placeholder,labelFn,valueFn){el.innerHTML=(placeholder?`<option value="">${esc(placeholder)}</option>`:'')+items.map(x=>`<option value="${esc(valueFn(x))}">${esc(labelFn(x))}</option>`).join('')}
function fillSelects(){
 fill($('clockSite'),sites,'Select work site',s=>s.name+' — '+s.address,s=>s.id);
 fill($('reportSite'),sites,'All sites',s=>s.name,s=>s.id);
 fill($('reportStaff'),staff,'All employees',p=>(p.full_name||p.email)+' ('+p.role+')',p=>p.id);
}
function myOpen(){return attendance.find(a=>a.user_id===session.user.id&&!a.check_out)}
function renderClock(){
 const day=bahrainDay(),today=attendance.filter(a=>a.work_day===day);
 $('todayMetric').textContent=today.length;$('openMetric').textContent=attendance.filter(a=>!a.check_out).length;$('siteMetric').textContent=sites.length;
 const active=myOpen();$('myShift').innerHTML=active?`<span class="pill">Checked in</span><p><b>${esc(active.site_name)}</b></p><p class="muted">Since ${esc(new Date(active.check_in).toLocaleString('en-GB',{timeZone:'Asia/Bahrain'}))}</p>`:'<span class="pill off">Not checked in</span><p class="muted">Take a selfie and capture GPS to record attendance.</p>';
 const recent=attendance.slice(0,5);$('recent').innerHTML=recent.length?recent.map(a=>`<div style="padding:7px 0;border-bottom:1px solid #e4e7ec"><b>${esc(a.employee_name||a.user_id)}</b><br>${esc(a.site_name)} · ${esc(new Date(a.check_in).toLocaleString('en-GB',{timeZone:'Asia/Bahrain'}))}</div>`).join(''):'No activity yet.';
 $('recentTable').innerHTML=attendance.length?tableAttendance(attendance.slice(0,30)):'<div class="empty">No attendance records yet.</div>';
}
function tableAttendance(rows){return `<table><thead><tr><th>Date</th><th>Employee</th><th>Site</th><th>Check in</th><th>Check out</th><th>Selfie</th></tr></thead><tbody>${rows.map(a=>`<tr><td>${esc(a.work_day)}</td><td>${esc(a.employee_name||'')}</td><td>${esc(a.site_name)}</td><td>${esc(new Date(a.check_in).toLocaleTimeString('en-GB',{timeZone:'Asia/Bahrain'}))}</td><td>${a.check_out?esc(new Date(a.check_out).toLocaleTimeString('en-GB',{timeZone:'Asia/Bahrain'})):'—'}</td><td>${a.selfie_path?'Private photo saved':'—'}</td></tr>`).join('')}</tbody></table>`}
function captureGPS(){
 if(!navigator.geolocation)return message('clockMsg','GPS is not supported by this device.');
 message('gpsText','Requesting location…');
 navigator.geolocation.getCurrentPosition(p=>{gps={lat:p.coords.latitude,lon:p.coords.longitude,accuracy:Math.round(p.coords.accuracy)};message('gpsText',`${gps.lat.toFixed(5)}, ${gps.lon.toFixed(5)} (±${gps.accuracy} m)`);},e=>message('gpsText','Location error: '+e.message),{enableHighAccuracy:true,timeout:15000,maximumAge:0});
}
async function uploadSelfie(){
 if(!currentPhoto)throw new Error('Please take/select a selfie first.');
 const ext=(currentPhoto.name.split('.').pop()||'jpg').toLowerCase().replace(/[^a-z0-9]/g,'')||'jpg';
 const path=`${session.user.id}/${Date.now()}.${ext}`;
 const {error}=await supabase.storage.from('attendance-selfies').upload(path,currentPhoto,{contentType:currentPhoto.type||'image/jpeg',upsert:false});
 if(error)throw error;return path;
}
async function punch(kind){
 try{
  if(!sites.length)throw new Error('No work sites have been registered yet. Ask an administrator.');
  if(!gps)throw new Error('Capture GPS before submitting.');
  const site=sites.find(s=>s.id===$('clockSite').value);if(!site)throw new Error('Choose a registered work site.');
  const active=myOpen();
  if(kind==='in'&&active)throw new Error('You are already checked in. Check out first.');
  if(kind==='out'&&!active)throw new Error('You do not have an open shift.');
  if(kind==='out'&&active.site_id!==site.id)throw new Error('Choose the same site you checked in at to check out.');
  message('clockMsg','Uploading selfie and saving attendance…');
  const selfie_path=await uploadSelfie();
  if(kind==='in'){
   const {error}=await supabase.from('attendance').insert({user_id:session.user.id,employee_name:profile.full_name||session.user.email,site_id:site.id,site_name:site.name,work_day:bahrainDay(),check_in:bahrainTimestamp(),check_in_lat:gps.lat,check_in_lon:gps.lon,check_in_accuracy:gps.accuracy,selfie_path,note:$('note').value.trim()||null});
   if(error)throw error;
  }else{
   const {error}=await supabase.from('attendance').update({check_out:bahrainTimestamp(),check_out_lat:gps.lat,check_out_lon:gps.lon,check_out_accuracy:gps.accuracy,check_out_selfie_path:selfie_path,checkout_note:$('note').value.trim()||null}).eq('id',active.id);
   if(error)throw error;
  }
  currentPhoto=null;gps=null;$('photo').value='';$('note').value='';message('gpsText','Not captured');message('clockMsg',kind==='in'?'Check-in saved.':'Check-out saved.');await loadData();
 }catch(e){message('clockMsg',e.message||String(e))}
}
function filtered(){
 const from=$('fromDate').value,to=$('toDate').value,staffId=$('reportStaff').value,siteId=$('reportSite').value;
 return attendance.filter(a=>(!from||a.work_day>=from)&&(!to||a.work_day<=to)&&(!staffId||a.user_id===staffId)&&(!siteId||a.site_id===siteId));
}
function duration(a){if(!a.check_out)return '';return Math.max(0,Math.round((new Date(a.check_out)-new Date(a.check_in))/60000))}
function renderReports(){
 if(!$('reportTable'))return;
 const rows=filtered();let mins=rows.reduce((n,a)=>n+duration(a),0);
 $('reportSummary').textContent=`${rows.length} shift(s) · ${Math.floor(mins/60)}h ${mins%60}m completed duration (unclosed shifts excluded).`;
 $('reportTable').innerHTML=rows.length?`<table><thead><tr><th>Date</th><th>Employee</th><th>Site</th><th>Check in</th><th>Check out</th><th>Duration</th><th>GPS</th></tr></thead><tbody>${rows.map(a=>{const d=duration(a);return `<tr><td>${esc(a.work_day)}</td><td>${esc(a.employee_name||'')}</td><td>${esc(a.site_name)}</td><td>${esc(new Date(a.check_in).toLocaleTimeString('en-GB',{timeZone:'Asia/Bahrain'}))}</td><td>${a.check_out?esc(new Date(a.check_out).toLocaleTimeString('en-GB',{timeZone:'Asia/Bahrain'})):'—'}</td><td>${d===''?'—':Math.floor(d/60)+'h '+d%60+'m'}</td><td>${a.check_in_lat!=null?`<a target="_blank" rel="noopener" href="https://maps.google.com/?q=${a.check_in_lat},${a.check_in_lon}">Check-in map</a>`:'—'}</td></tr>`}).join('')}</tbody></table>`:'<div class="empty">No records for these filters.</div>';
}
function exportCSV(){
 const rows=filtered(),headers=['Date','Employee','Employee email','Site','Check in','Check out','Duration minutes','Note','Check-in latitude','Check-in longitude','Check-in accuracy metres','Check-out latitude','Check-out longitude','Selfie storage path'];
 const csvVal=v=>{let s=String(v??'');return /[",\r\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s};
 const content=[headers,...rows.map(a=>[a.work_day,a.employee_name,staff.find(p=>p.id===a.user_id)?.email,a.site_name,a.check_in,a.check_out,duration(a),a.note,a.check_in_lat,a.check_in_lon,a.check_in_accuracy,a.check_out_lat,a.check_out_lon,a.selfie_path])].map(r=>r.map(csvVal).join(',')).join('\r\n');
 const url=URL.createObjectURL(new Blob(['\ufeff'+content],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=`almada-attendance-${bahrainDay()}.csv`;a.click();URL.revokeObjectURL(url);
}
async function addSite(){
 if(!isManager())return;
 const name=$('siteName').value.trim(),address=$('siteAddress').value.trim(),radius=Number($('siteRadius').value)||200;if(!name||!address)return message('siteMsg','Enter site name and address.');
 const {error}=await supabase.from('sites').insert({name,address,radius_m:Math.max(50,Math.min(5000,radius)),created_by:session.user.id});
 message('siteMsg',error?.message||'Site added.');if(!error){$('siteName').value='';$('siteAddress').value='';await loadData()}
}
function renderSites(){
 if(!$('sitesTable'))return;
 $('sitesTable').innerHTML=sites.length?`<table><thead><tr><th>Site</th><th>Address</th><th>Radius</th>${isManager()?'<th></th>':''}</tr></thead><tbody>${sites.map(s=>`<tr><td>${esc(s.name)}</td><td>${esc(s.address)}</td><td>${s.radius_m} m</td>${isManager()?`<td><button class="danger" data-del-site="${s.id}">Delete</button></td>`:''}</tr>`).join('')}</tbody></table>`:'<div class="empty">No sites registered.</div>';
 document.querySelectorAll('[data-del-site]').forEach(b=>b.onclick=async()=>{if(!isAdmin())return message('siteMsg','Only an admin can delete sites.');if(!confirm('Delete this site? Historical attendance remains.'))return;const {error}=await supabase.from('sites').delete().eq('id',b.dataset.delSite);message('siteMsg',error?.message||'Site deleted.');await loadData()});
}
function renderStaff(){
 if(!$('staffTable'))return;
 if(!isManager()){$('staffTable').innerHTML='<div class="empty">Admin or supervisor access required.</div>';return}
 $('staffTable').innerHTML=staff.length?`<table><thead><tr><th>Email</th><th>Name</th><th>Role</th>${isAdmin()?'<th>Change role</th>':''}</tr></thead><tbody>${staff.map(p=>`<tr><td>${esc(p.email)}</td><td>${esc(p.full_name||'')}</td><td>${esc(p.role)}</td>${isAdmin()?`<td><select data-role="${p.id}"><option value="employee" ${p.role==='employee'?'selected':''}>Employee</option><option value="supervisor" ${p.role==='supervisor'?'selected':''}>Supervisor</option><option value="admin" ${p.role==='admin'?'selected':''}>Admin</option></select><button data-save-role="${p.id}" style="margin-top:5px">Save</button></td>`:''}</tr>`).join('')}</tbody></table>`:'<div class="empty">No employee accounts.</div>';
 document.querySelectorAll('[data-save-role]').forEach(b=>b.onclick=async()=>{const id=b.dataset.saveRole,role=document.querySelector(`[data-role="${id}"]`).value;if(id===session.user.id&&role!=='admin')return message('staffMsg','You cannot remove your own admin role from this screen.');const {error}=await supabase.from('profiles').update({role}).eq('id',id);message('staffMsg',error?.message||'Role updated.');await loadData()});
}
async function start(){
 const c=config();if(!c){showSetup();return}
 supabase=createClient(c.url,c.key);
 const {data:{session:s}}=await supabase.auth.getSession();session=s;
 supabase.auth.onAuthStateChange((_event,sess)=>{session=sess;if(sess)bootstrap();else renderAuth()});
 if(!session){renderAuth();return}
 await bootstrap();
}
async function bootstrap(){
 const {data:p,error}=await supabase.from('profiles').select('*').eq('id',session.user.id).maybeSingle();
 if(error){renderShell();message('clockMsg','Profile lookup failed: '+error.message);return}
 if(!p){renderShell();message('clockMsg','Your profile is not ready. Sign out and sign in again. If this persists, check the database setup SQL.');return}
 profile=p;renderShell();
}
start();
